#!/bin/sh

python3 -m pip uninstall --yes "fourletterphat"

exit 0

